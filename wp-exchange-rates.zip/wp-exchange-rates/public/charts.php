

<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

// دریافت ارز از query param یا پیش‌فرض RUB
$currency = $_GET['currency'] ?? 'RUB';

// گرفتن میانگین قیمت روزانه
$rows = $wpdb->get_results(
    $wpdb->prepare(
        "SELECT run_date, AVG(price) as avg_price
         FROM {$wpdb->prefix}exchange_prices
         WHERE currency = %s
         GROUP BY run_date
         ORDER BY run_date ASC",
        $currency
    )
);

if (!$rows) {
    echo "<p>داده‌ای برای ارز {$currency} موجود نیست.</p>";
    return;
}

$dates = [];
$prices = [];

foreach ($rows as $row) {
    $dates[] = $row->run_date;
    $prices[] = floatval($row->avg_price);
}
?>

<div style="width:100%; max-width:800px;">
    <canvas id="exchangeChart" height="400"></canvas>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx = document.getElementById('exchangeChart').getContext('2d');
const exchangeChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: <?php echo json_encode($dates); ?>,
        datasets: [{
            label: '<?php echo $currency; ?> میانگین قیمت روزانه (ریال)',
            data: <?php echo json_encode($prices); ?>,
            borderColor: 'rgba(54, 162, 235, 1)',
            backgroundColor: 'rgba(54, 162, 235, 0.2)',
            tension: 0.3,
            pointRadius: 3,
            pointHoverRadius: 6
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { display: true },
            tooltip: { mode: 'index', intersect: false }
        },
        interaction: {
            mode: 'nearest',
            axis: 'x',
            intersect: false
        },
        scales: {
            x: {
                title: { display: true, text: 'تاریخ' },
                type: 'time',
                time: { unit: 'day', tooltipFormat: 'YYYY-MM-DD' }
            },
            y: {
                title: { display: true, text: 'قیمت (ریال)' }
            }
        }
    }
});
</script>
