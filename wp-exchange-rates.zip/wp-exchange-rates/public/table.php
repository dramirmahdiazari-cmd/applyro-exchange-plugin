<?php
if (!defined('ABSPATH')) {
    exit;
}

// دریافت آدرس پروفایل عمومی صراف
function wer_get_vendor_profile_url($vendor_id) {
    // پیدا کردن صفحه‌ای که شورتکد vendor_public_profile را دارد
    $pages = get_pages(array(
        'post_status' => 'publish',
    ));
    
    foreach ($pages as $page) {
        if (has_shortcode($page->post_content, 'vendor_public_profile')) {
            return add_query_arg('vendor_id', $vendor_id, get_permalink($page->ID));
        }
    }
    
    // اگر صفحه‌ای با این شورتکد پیدا نشد، از صفحه فعلی استفاده کن
    global $wp;
    $current_url = home_url(add_query_arg(array(), $wp->request));
    return add_query_arg('vendor_id', $vendor_id, $current_url);
}

function wer_get_latest_price($source, $currency) {
    global $wpdb;

    if (strpos($source, 'vendor_') === 0) {
        $vendor_id = str_replace('vendor_', '', $source);
        
        $table = $wpdb->prefix . 'exchange_vendor_prices';
        
        $sql = $wpdb->prepare(
            "SELECT sell_price 
             FROM $table
             WHERE exchange_id = %d AND currency = %s AND price_date = CURDATE()
             ORDER BY created_at DESC
             LIMIT 1",
            $vendor_id,
            $currency
        );
        
        $price = $wpdb->get_var($sql);
        
        return is_null($price) ? '-' : number_format($price);
    } else {
        $table = $wpdb->prefix . 'exchange_prices';

        $sql = $wpdb->prepare(
            "SELECT price 
             FROM $table
             WHERE source = %s AND currency = %s
             ORDER BY run_date DESC, run_time DESC
             LIMIT 1",
            $source,
            $currency
        );

        $price = $wpdb->get_var($sql);

        return is_null($price) ? '-' : number_format($price);
    }
}

function wer_get_vendor_volume($vendor_id, $currency) {
    global $wpdb;
    
    $table = $wpdb->prefix . 'exchange_vendor_prices';
    
    $sql = $wpdb->prepare(
        "SELECT volume 
         FROM $table
         WHERE exchange_id = %d AND currency = %s AND price_date = CURDATE()
         ORDER BY created_at DESC
         LIMIT 1",
        $vendor_id,
        $currency
    );
    
    $volume = $wpdb->get_var($sql);
    
    return is_null($volume) ? '-' : number_format($volume);
}

function wer_get_vendor_has_today_prices($vendor_id) {
    global $wpdb;
    
    $table = $wpdb->prefix . 'exchange_vendor_prices';
    
    $sql = $wpdb->prepare(
        "SELECT COUNT(*) 
         FROM $table
         WHERE exchange_id = %d AND price_date = CURDATE()",
        $vendor_id
    );
    
    return (int)$wpdb->get_var($sql) > 0;
}

function wer_render_exchange_table() {
    global $wpdb;

    $currencies = [
        'USD' => ['name' => 'دلار', 'flag' => '🇺🇸', 'symbol' => '$'],
        'RUB' => ['name' => 'روبل', 'flag' => '🇷🇺', 'symbol' => '₽'],
        'EUR' => ['name' => 'یورو', 'flag' => '🇪🇺', 'symbol' => '€'],
        'TRY' => ['name' => 'لیر ترکیه', 'flag' => '🇹🇷', 'symbol' => '₺'],
    ];

    // دریافت سایت‌های خارجی
    $external_sources = $wpdb->get_results(
        "SELECT source, display_name, contact_info
         FROM {$wpdb->prefix}exchange_sources
         WHERE is_active = 1
         ORDER BY id ASC"
    );

    // دریافت صراف‌های داخلی تایید شده (همه حتی بدون قیمت)
    $internal_sources = $wpdb->get_results(
        "SELECT e.id, e.exchange_name_fa, e.exchange_name_en, e.phone, e.whatsapp, e.telegram, e.instagram,
                e.country, e.city, e.rating, e.total_ratings,
                COUNT(CASE WHEN p.price_date = CURDATE() THEN p.id END) as today_price_count,
                COUNT(p.id) as total_price_count
         FROM {$wpdb->prefix}exchanges e
         LEFT JOIN {$wpdb->prefix}exchange_vendor_prices p ON e.id = p.exchange_id
         WHERE e.status = 'verified'
         GROUP BY e.id
         ORDER BY e.exchange_name_fa ASC"
    );

    // جمع قیمت‌ها برای میانگین (فقط منابعی که قیمت دارند)
    $all_prices = [];
    foreach ($currencies as $code => $data) {
        $all_prices[$code] = [];
    }

    ob_start();
    ?>

    <div class="wer-exchange-container">
        <!-- هدر جدول -->
        <div class="wer-table-header">
            <div class="wer-header-title">
                <h2><i class="fas fa-chart-line"></i> لیست قیمت ارز</h2>
                <p>آخرین نرخ‌های ارز از صرافی‌های معتبر</p>
            </div>
            
            <div class="wer-header-controls">
                <!-- سوئیچ تومان / ریال (تومان اول) -->
                <div class="wer-currency-switch">
                    <span class="wer-switch-btn active" data-unit="toman">
                        <i class="fas fa-coins"></i>
                        تومان
                    </span>
                    <span class="wer-switch-btn" data-unit="rial">
                        <i class="fas fa-money-bill-wave"></i>
                        ریال
                    </span>
                </div>
                
                <!-- بروزرسانی -->
                <div class="wer-update-info">
                    <i class="fas fa-sync-alt"></i>
                    آخرین بروزرسانی: <?php echo current_time('j F Y - H:i'); ?>
                </div>
            </div>
        </div>

        <!-- جدول قیمت‌ها -->
        <div class="wer-table-responsive">
            <table class="wer-exchange-table">
                <thead>
                    <tr>
                        <th class="wer-col-source">
                            <i class="fas fa-store"></i>
                            مرجع / صراف
                        </th>
                        <?php foreach ($currencies as $code => $data): ?>
                            <th class="wer-col-currency">
                                <div class="currency-header">
                                    <span class="currency-flag"><?php echo $data['flag']; ?></span>
                                    <span class="currency-name"><?php echo $data['name']; ?></span>
                                    <span class="currency-code"><?php echo $code; ?></span>
                                </div>
                            </th>
                        <?php endforeach; ?>
                        <th class="wer-col-volume">
                            <i class="fas fa-boxes"></i>
                            حجم
                        </th>
                        <th class="wer-col-update">
                            <i class="fas fa-clock"></i>
                            بروزرسانی
                        </th>
                        <th class="wer-col-actions">
                            <i class="fas fa-phone"></i>
                            اطلاعات تماس
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <!-- سایت‌های خارجی -->
                    <?php foreach ($external_sources as $source): ?>
                        <?php
                        $last_update = $wpdb->get_row(
                            $wpdb->prepare(
                                "SELECT run_date, run_time
                                 FROM {$wpdb->prefix}exchange_prices
                                 WHERE source = %s
                                 ORDER BY run_date DESC, run_time DESC
                                 LIMIT 1",
                                $source->source
                            )
                        );

                        if ($last_update) {
                            $hour = str_pad($last_update->run_time, 2, '0', STR_PAD_LEFT) . ':00';
                            $update_text = date_i18n('Y/m/d', strtotime($last_update->run_date)) . ' ' . $hour;
                            $time_ago = human_time_diff(
                                strtotime($last_update->run_date . ' ' . $hour),
                                current_time('timestamp')
                            ) . ' قبل';
                        } else {
                            $update_text = '-';
                            $time_ago = '-';
                        }
                        ?>

                        <tr class="wer-source-row wer-external">
                            <td class="wer-source-info">
                                <div class="source-name">
                                    <i class="fas fa-globe"></i>
                                    <strong><?php echo esc_html($source->display_name ?: $source->source); ?></strong>
                                </div>
                                <div class="source-type">
                                    <span class="badge badge-external">منبع خارجی</span>
                                </div>
                            </td>

                            <?php foreach ($currencies as $code => $data):
                                $price = wer_get_latest_price($source->source, $code);
                                $raw_price = $price !== '-' ? str_replace(',', '', $price) : '';
                                
                                if ($price !== '-') {
                                    $all_prices[$code][] = floatval(str_replace(',', '', $price));
                                }
                                
                                // محاسبه تومان (تقسیم بر 10)
                                $toman_price = $raw_price !== '' ? number_format(floatval($raw_price) / 10) : '';
                            ?>
                                <td class="wer-price-cell" data-price="<?php echo esc_attr($raw_price); ?>" data-toman="<?php echo esc_attr($toman_price); ?>">
                                    <?php if ($price !== '-'): ?>
                                        <div class="price-display" style="display: none;">
                                            <span class="price-value"><?php echo esc_html($price); ?></span>
                                            <span class="price-symbol">ریال</span>
                                        </div>
                                        <div class="price-toman">
                                            <span class="price-value"><?php echo esc_html($toman_price); ?></span>
                                            <span class="price-symbol">تومان</span>
                                        </div>
                                    <?php else: ?>
                                        <span class="price-empty">—</span>
                                    <?php endif; ?>
                                </td>
                            <?php endforeach; ?>

                            <!-- ستون حجم -->
                            <td class="wer-volume-cell">
                                <span class="volume-empty">—</span>
                            </td>

                            <!-- ستون بروزرسانی -->
                            <td class="wer-update-cell">
                                <div class="update-time">
                                    <i class="far fa-calendar-alt"></i>
                                    <?php echo esc_html($update_text); ?>
                                </div>
                                <div class="update-ago">
                                    <small><?php echo esc_html($time_ago); ?></small>
                                </div>
                            </td>

                            <!-- ستون اطلاعات تماس -->
                            <td class="wer-contact-cell">
                                <?php if ($source->contact_info): ?>
                                    <div class="contact-info">
                                        <i class="fas fa-info-circle"></i>
                                        <?php echo esc_html($source->contact_info); ?>
                                    </div>
                                <?php else: ?>
                                    <span class="contact-empty">—</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                    <!-- صراف‌های داخلی -->
                    <?php foreach ($internal_sources as $vendor): 
                        $has_today_prices = wer_get_vendor_has_today_prices($vendor->id);
                        
                        // دریافت آخرین بروزرسانی (از هر روز، نه فقط امروز)
                        $last_update = $wpdb->get_row(
                            $wpdb->prepare(
                                "SELECT created_at, price_date
                                 FROM {$wpdb->prefix}exchange_vendor_prices
                                 WHERE exchange_id = %d
                                 ORDER BY created_at DESC
                                 LIMIT 1",
                                $vendor->id
                            )
                        );

                        if ($last_update) {
                            $update_text = date_i18n('Y/m/d H:i', strtotime($last_update->created_at));
                            $time_ago = human_time_diff(
                                strtotime($last_update->created_at),
                                current_time('timestamp')
                            ) . ' قبل';
                        } else {
                            $update_text = 'هنوز قیمتی ثبت نشده';
                            $time_ago = '—';
                        }
                        
                        // لینک پروفایل
                        $profile_url = wer_get_vendor_profile_url($vendor->id);
                        ?>

                        <tr class="wer-source-row wer-internal <?php echo $has_today_prices ? '' : 'no-price-today'; ?>">
                            <td class="wer-source-info">
                                <div class="source-name">
                                    <i class="fas fa-store-alt"></i>
                                    <strong><?php echo esc_html($vendor->exchange_name_fa); ?></strong>
                                    <?php if ($vendor->exchange_name_en): ?>
                                        <small><?php echo esc_html($vendor->exchange_name_en); ?></small>
                                    <?php endif; ?>
                                </div>
                                <div class="source-type">
                                    <span class="badge badge-internal">صراف داخلی</span>
                                    <?php if (!$has_today_prices): ?>
                                        <span class="badge badge-warning">
                                            <i class="fas fa-clock"></i>
                                            قیمت امروز
                                        </span>
                                    <?php endif; ?>
                                    <?php if ($vendor->rating > 0): ?>
                                        <span class="badge badge-rating">
                                            <i class="fas fa-star"></i>
                                            <?php echo number_format($vendor->rating, 1); ?>
                                            (<?php echo $vendor->total_ratings; ?>)
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </td>

                            <?php 
                            $vendor_volumes = [];
                            $has_any_price = false;
                            foreach ($currencies as $code => $data):
                                $source_key = 'vendor_' . $vendor->id;
                                $price = wer_get_latest_price($source_key, $code);
                                $raw_price = $price !== '-' ? str_replace(',', '', $price) : '';
                                
                                if ($price !== '-') {
                                    $all_prices[$code][] = floatval(str_replace(',', '', $price));
                                    $has_any_price = true;
                                }
                                
                                $volume = wer_get_vendor_volume($vendor->id, $code);
                                $vendor_volumes[$code] = $volume;
                                
                                // محاسبه تومان
                                $toman_price = $raw_price !== '' ? number_format(floatval($raw_price) / 10) : '';
                            ?>
                                <td class="wer-price-cell" data-price="<?php echo esc_attr($raw_price); ?>" data-toman="<?php echo esc_attr($toman_price); ?>">
                                    <?php if ($price !== '-'): ?>
                                        <div class="price-display" style="display: none;">
                                            <span class="price-value"><?php echo esc_html($price); ?></span>
                                            <span class="price-symbol">ریال</span>
                                        </div>
                                        <div class="price-toman">
                                            <span class="price-value"><?php echo esc_html($toman_price); ?></span>
                                            <span class="price-symbol">تومان</span>
                                        </div>
                                    <?php else: ?>
                                        <span class="price-empty">—</span>
                                    <?php endif; ?>
                                </td>
                            <?php endforeach; ?>

                            <!-- ستون حجم -->
                            <td class="wer-volume-cell">
                                <?php 
                                $has_volume = false;
                                foreach ($currencies as $code => $data) {
                                    if ($vendor_volumes[$code] !== '-') {
                                        $has_volume = true;
                                        break;
                                    }
                                }
                                ?>
                                
                                <?php if ($has_volume): ?>
                                    <div class="vendor-volume-details">
                                        <?php foreach ($currencies as $code => $data): 
                                            if ($vendor_volumes[$code] !== '-'): ?>
                                            <div class="volume-item">
                                                <span class="volume-currency"><?php echo $data['flag']; ?> <?php echo $code; ?></span>
                                                <span class="volume-value"><?php echo $vendor_volumes[$code]; ?></span>
                                            </div>
                                            <?php endif;
                                        endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <span class="volume-empty">—</span>
                                <?php endif; ?>
                            </td>

                            <!-- ستون بروزرسانی -->
                            <td class="wer-update-cell">
                                <div class="update-time">
                                    <i class="far fa-clock"></i>
                                    <?php echo esc_html($update_text); ?>
                                </div>
                                <div class="update-ago">
                                    <small><?php echo esc_html($time_ago); ?></small>
                                </div>
                            </td>

                            <!-- ستون اطلاعات تماس -->
                            <td class="wer-contact-cell">
                                <div class="vendor-contact-actions">
                                    <!-- دکمه پروفایل -->
                                    <a href="<?php echo esc_url($profile_url); ?>" 
                                       class="btn-profile" 
                                       target="_blank"
                                       title="مشاهده پروفایل کامل">
                                        <i class="fas fa-user-circle"></i>
                                        پروفایل
                                    </a>
                                    
                                    <!-- آیکون‌های شبکه‌های اجتماعی کنار هم -->
                                    <div class="social-icons">
                                        <?php if ($vendor->phone): ?>
                                        <a href="tel:<?php echo esc_attr($vendor->phone); ?>" 
                                           class="social-icon btn-phone"
                                           title="تماس تلفنی">
                                            <i class="fas fa-phone-alt"></i>
                                        </a>
                                        <?php endif; ?>
                                        
                                        <?php if ($vendor->whatsapp): ?>
                                        <a href="https://wa.me/<?php echo esc_attr($vendor->whatsapp); ?>" 
                                           class="social-icon btn-whatsapp"
                                           target="_blank"
                                           title="واتساپ">
                                            <i class="fab fa-whatsapp"></i>
                                        </a>
                                        <?php endif; ?>
                                        
                                        <?php if ($vendor->telegram): ?>
                                        <a href="https://t.me/<?php echo esc_attr($vendor->telegram); ?>" 
                                           class="social-icon btn-telegram"
                                           target="_blank"
                                           title="تلگرام">
                                            <i class="fab fa-telegram"></i>
                                        </a>
                                        <?php endif; ?>
                                        
                                        <?php if ($vendor->instagram): ?>
                                        <a href="https://instagram.com/<?php echo esc_attr($vendor->instagram); ?>" 
                                           class="social-icon btn-instagram"
                                           target="_blank"
                                           title="اینستاگرام">
                                            <i class="fab fa-instagram"></i>
                                        </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                    <!-- ردیف میانگین -->
                    <?php
                    // محاسبه میانگین برای هر ارز
                    $averages = [];
                    foreach ($all_prices as $code => $values) {
                        if (count($values) > 0) {
                            $avg_rial = round(array_sum($values) / count($values));
                            $avg_toman = number_format($avg_rial / 10);
                        } else {
                            $avg_rial = '';
                            $avg_toman = '';
                        }
                        $averages[$code] = [
                            'rial' => $avg_rial,
                            'toman' => $avg_toman
                        ];
                    }
                    ?>
                    
                    <tr class="wer-average-row">
                        <td class="wer-average-label">
                            <i class="fas fa-calculator"></i>
                            <strong>میانگین قیمت‌ها</strong>
                        </td>

                        <?php foreach ($averages as $code => $avg_data): ?>
                            <td class="wer-average-cell" data-price="<?php echo esc_attr($avg_data['rial']); ?>" data-toman="<?php echo esc_attr($avg_data['toman']); ?>">
                                <?php if ($avg_data['rial']): ?>
                                    <div class="avg-display" style="display: none;">
                                        <span class="avg-value"><?php echo number_format($avg_data['rial']); ?></span>
                                        <span class="avg-symbol">ریال</span>
                                    </div>
                                    <div class="avg-toman">
                                        <span class="avg-value"><?php echo $avg_data['toman']; ?></span>
                                        <span class="avg-symbol">تومان</span>
                                    </div>
                                <?php else: ?>
                                    <span class="avg-empty">—</span>
                                <?php endif; ?>
                            </td>
                        <?php endforeach; ?>

                        <td class="wer-average-volume">—</td>
                        <td class="wer-average-update">—</td>
                        <td class="wer-average-contact">—</td>
                    </tr>

                </tbody>
            </table>
        </div>

        <!-- توضیحات پایین جدول -->
        <div class="wer-table-footer">
            <div class="wer-legend">
                <div class="legend-item">
                    <span class="legend-color" style="background: #e3f2fd;"></span>
                    <span>منابع خارجی</span>
                </div>
                <div class="legend-item">
                    <span class="legend-color" style="background: #e8f5e9;"></span>
                    <span>صراف‌های داخلی</span>
                </div>
                <div class="legend-item">
                    <span class="legend-color" style="background: #fffde7;"></span>
                    <span>بدون قیمت امروز</span>
                </div>
                <div class="legend-item">
                    <span class="legend-color" style="background: #fff3e0;"></span>
                    <span>میانگین قیمت</span>
                </div>
            </div>
            
            <div class="wer-disclaimer">
                <i class="fas fa-exclamation-circle"></i>
                <small>تمامی قیمت‌ها به تومان بوده و می‌توانید با کلیک روی دکمه ریال، قیمت‌ها را به ریال مشاهده کنید.</small>
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // سوئیچ تومان/ریال (تومان اول)
        const switcher = document.querySelector('.wer-currency-switch');
        const priceCells = document.querySelectorAll('.wer-price-cell');
        const avgCells = document.querySelectorAll('.wer-average-cell');
        
        if (switcher) {
            switcher.addEventListener('click', function(e) {
                const btn = e.target.closest('.wer-switch-btn');
                if (!btn || btn.classList.contains('active')) return;
                
                // تغییر حالت دکمه‌ها
                switcher.querySelectorAll('.wer-switch-btn').forEach(el => {
                    el.classList.remove('active');
                });
                btn.classList.add('active');
                
                const unit = btn.dataset.unit;
                
                // تبدیل قیمت‌ها
                priceCells.forEach(cell => {
                    const priceDisplay = cell.querySelector('.price-display');
                    const tomanDisplay = cell.querySelector('.price-toman');
                    
                    if (priceDisplay && tomanDisplay) {
                        if (unit === 'rial') {
                            priceDisplay.style.display = 'block';
                            tomanDisplay.style.display = 'none';
                        } else {
                            priceDisplay.style.display = 'none';
                            tomanDisplay.style.display = 'block';
                        }
                    }
                });
                
                // تبدیل میانگین‌ها
                avgCells.forEach(cell => {
                    const avgDisplay = cell.querySelector('.avg-display');
                    const avgToman = cell.querySelector('.avg-toman');
                    
                    if (avgDisplay && avgToman) {
                        if (unit === 'rial') {
                            avgDisplay.style.display = 'block';
                            avgToman.style.display = 'none';
                        } else {
                            avgDisplay.style.display = 'none';
                            avgToman.style.display = 'block';
                        }
                    }
                });
            });
        }
        
        // هایلایت بهترین قیمت در هر ستون (فقط برای صراف‌هایی که قیمت دارند)
        const tableRows = document.querySelectorAll('.wer-source-row:not(.wer-average-row)');
        const currencyCount = <?php echo count($currencies); ?>;
        
        for (let i = 1; i <= currencyCount; i++) {
            let minPrice = Infinity;
            let bestRow = null;
            
            tableRows.forEach(row => {
                if (row.classList.contains('no-price-today')) return; // صراف‌هایی که قیمت ندارند را در نظر نگیر
                
                const cell = row.children[i];
                if (!cell) return;
                
                // استفاده از قیمت تومان (پیش‌فرض)
                let priceAttr = cell.getAttribute('data-toman');
                if (!priceAttr || priceAttr === '') {
                    priceAttr = cell.getAttribute('data-price');
                }
                
                if (!priceAttr || priceAttr === '') return;
                
                // حذف کاما از عدد
                const price = parseFloat(priceAttr.replace(/,/g, ''));
                if (!isNaN(price) && price < minPrice) {
                    minPrice = price;
                    bestRow = row;
                }
            });
            
            if (bestRow) {
                const bestCell = bestRow.children[i];
                if (bestCell) {
                    bestCell.classList.add('best-price');
                    
                    // اضافه کردن نشانگر
                    const marker = document.createElement('span');
                    marker.className = 'best-price-marker';
                    marker.innerHTML = '<i class="fas fa-crown"></i>';
                    bestCell.appendChild(marker);
                }
            }
        }
        
        // نمایش جزئیات حجم در موبایل
        const volumeCells = document.querySelectorAll('.wer-volume-cell');
        if (window.innerWidth <= 768) {
            volumeCells.forEach(cell => {
                const volumeDetails = cell.querySelector('.vendor-volume-details');
                if (volumeDetails && volumeDetails.children.length > 0) {
                    const toggleBtn = document.createElement('button');
                    toggleBtn.type = 'button';
                    toggleBtn.className = 'volume-toggle';
                    toggleBtn.innerHTML = '<i class="fas fa-eye"></i> حجم';
                    toggleBtn.addEventListener('click', function() {
                        if (volumeDetails.style.display === 'none' || volumeDetails.style.display === '') {
                            volumeDetails.style.display = 'block';
                            this.innerHTML = '<i class="fas fa-eye-slash"></i> بستن';
                        } else {
                            volumeDetails.style.display = 'none';
                            this.innerHTML = '<i class="fas fa-eye"></i> حجم';
                        }
                    });
                    
                    const wrapper = document.createElement('div');
                    wrapper.className = 'volume-mobile-wrapper';
                    wrapper.appendChild(toggleBtn);
                    cell.appendChild(wrapper);
                    
                    // مخفی کردن جزئیات در حالت اولیه
                    volumeDetails.style.display = 'none';
                }
            });
        }
    });
    </script>

    <!-- CSS Styles -->
    <style>
    /* استایل کلی */
    .wer-exchange-container {
        background: #fff;
        border-radius: 16px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        overflow: hidden;
        margin: 30px 0;
        font-family: 'Vazir', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    
    /* هدر */
    .wer-table-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 25px 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 20px;
    }
    
    .wer-header-title h2 {
        margin: 0 0 10px 0;
        font-size: 24px;
        font-weight: 600;
    }
    
    .wer-header-title p {
        margin: 0;
        opacity: 0.9;
        font-size: 14px;
    }
    
    /* سوئیچ ارز (تومان اول) */
    .wer-currency-switch {
        background: rgba(255, 255, 255, 0.15);
        border-radius: 50px;
        padding: 4px;
        display: inline-flex;
        backdrop-filter: blur(10px);
        order: 1;
    }
    
    .wer-switch-btn {
        padding: 8px 20px;
        border-radius: 50px;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 14px;
    }
    
    .wer-switch-btn.active {
        background: white;
        color: #764ba2;
        font-weight: 500;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }
    
    .wer-switch-btn:not(.active):hover {
        background: rgba(255, 255, 255, 0.1);
    }
    
    .wer-update-info {
        order: 2;
        font-size: 13px;
        opacity: 0.9;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    /* جدول */
    .wer-table-responsive {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }
    
    .wer-exchange-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 800px;
    }
    
    /* هدر جدول */
    .wer-exchange-table thead {
        background: #f8fafc;
        border-bottom: 2px solid #e2e8f0;
    }
    
    .wer-exchange-table th {
        padding: 18px 15px;
        text-align: center;
        font-weight: 600;
        color: #475569;
        font-size: 14px;
        border-bottom: 2px solid #e2e8f0;
    }
    
    .currency-header {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 5px;
    }
    
    .currency-flag {
        font-size: 20px;
    }
    
    .currency-name {
        font-size: 12px;
    }
    
    .currency-code {
        background: #e2e8f0;
        padding: 2px 8px;
        border-radius: 10px;
        font-size: 10px;
        font-weight: bold;
    }
    
    /* ردیف‌ها */
    .wer-exchange-table td {
        padding: 16px 12px;
        text-align: center;
        border-bottom: 1px solid #f1f5f9;
        transition: background 0.2s ease;
    }
    
    .wer-source-row:hover {
        background: #f8fafc !important;
    }
    
    .wer-external {
        background: #f8fafc;
    }
    
    .wer-internal {
        background: #f0fdf4;
    }
    
    .no-price-today {
        background: #fffde7 !important;
        opacity: 0.9;
    }
    
    .wer-average-row {
        background: #fff3e0 !important;
        border-top: 2px solid #fbbf24;
    }
    
    .wer-average-row td {
        font-weight: 600;
        color: #92400e;
    }
    
    /* بج جدید برای هشدار قیمت امروز */
    .badge-warning {
        background: #fef3c7;
        color: #92400e;
        border: 1px solid #fbbf24;
    }
    
    /* سلول‌های قیمت */
    .wer-price-cell {
        min-width: 120px;
    }
    
    .price-display, .price-toman, .avg-display, .avg-toman {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 4px;
    }
    
    .price-value, .avg-value {
        font-size: 16px;
        font-weight: 600;
        color: #1e293b;
    }
    
    .price-symbol, .avg-symbol {
        font-size: 11px;
        color: #64748b;
        background: #f1f5f9;
        padding: 2px 8px;
        border-radius: 10px;
    }
    
    .price-empty, .volume-empty, .contact-empty, .avg-empty {
        color: #94a3b8;
        font-style: italic;
    }
    
    .no-price-today .price-empty {
        color: #f59e0b;
        font-style: normal;
    }
    
    /* بهترین قیمت */
    .best-price {
        position: relative;
        background: linear-gradient(135deg, #dbeafe 0%, #d1fae5 100%) !important;
        border: 2px solid #3b82f6 !important;
    }
    
    .best-price-marker {
        position: absolute;
        top: -8px;
        left: -8px;
        background: #3b82f6;
        color: white;
        width: 24px;
        height: 24px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 12px;
        box-shadow: 0 2px 5px rgba(59, 130, 246, 0.5);
    }
    
    /* اطلاعات منبع */
    .wer-source-info {
        min-width: 200px;
        text-align: right;
    }
    
    .source-name {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 8px;
    }
    
    .source-name i {
        color: #64748b;
        font-size: 14px;
    }
    
    .source-type {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
    }
    
    .badge {
        padding: 4px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 500;
    }
    
    .badge-external {
        background: #e0f2fe;
        color: #0369a1;
    }
    
    .badge-internal {
        background: #dcfce7;
        color: #15803d;
    }
    
    .badge-rating {
        background: #fef3c7;
        color: #92400e;
    }
    
    /* حجم */
    .vendor-volume-details {
        display: flex;
        flex-direction: column;
        gap: 6px;
    }
    
    .volume-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 4px 8px;
        background: #f8fafc;
        border-radius: 8px;
        font-size: 12px;
    }
    
    .volume-currency {
        color: #475569;
    }
    
    .volume-value {
        font-weight: 600;
        color: #1e293b;
    }
    
    /* بروزرسانی */
    .update-time {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        font-size: 13px;
        color: #475569;
    }
    
    .update-ago {
        margin-top: 4px;
        color: #94a3b8;
        font-size: 11px;
    }
    
    /* اطلاعات تماس */
    .vendor-contact-actions {
        display: flex;
        flex-direction: column;
        gap: 10px;
        align-items: center;
    }
    
    .btn-profile {
        padding: 8px 16px;
        background: #3b82f6;
        color: white;
        text-decoration: none;
        border-radius: 20px;
        font-size: 13px;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 8px;
        transition: all 0.3s ease;
    }
    
    .btn-profile:hover {
        background: #2563eb;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(37, 99, 235, 0.2);
    }
    
    .social-icons {
        display: flex;
        gap: 8px;
        justify-content: center;
        flex-wrap: wrap;
    }
    
    .social-icon {
        width: 36px;
        height: 36px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        text-decoration: none;
        color: white;
        font-size: 16px;
        transition: all 0.3s ease;
    }
    
    .social-icon:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }
    
    .btn-phone {
        background: #10b981;
    }
    
    .btn-whatsapp {
        background: #25d366;
    }
    
    .btn-telegram {
        background: #0088cc;
    }
    
    .btn-instagram {
        background: linear-gradient(45deg, #405de6, #5851db, #833ab4, #c13584, #e1306c, #fd1d1d);
    }
    
    /* فوتر */
    .wer-table-footer {
        padding: 20px 30px;
        background: #f8fafc;
        border-top: 1px solid #e2e8f0;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 20px;
    }
    
    .wer-legend {
        display: flex;
        gap: 20px;
        flex-wrap: wrap;
    }
    
    .legend-item {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 12px;
        color: #64748b;
    }
    
    .legend-color {
        width: 16px;
        height: 16px;
        border-radius: 4px;
        border: 1px solid #e2e8f0;
    }
    
    .wer-disclaimer {
        display: flex;
        align-items: center;
        gap: 8px;
        color: #64748b;
        font-size: 12px;
        max-width: 500px;
    }
    
    /* ریسپانسیو */
    @media (max-width: 1200px) {
        .wer-table-header {
            flex-direction: column;
            text-align: center;
        }
        
        .wer-header-controls {
            display: flex;
            flex-direction: column;
            gap: 15px;
            align-items: center;
            width: 100%;
        }
    }
    
    @media (max-width: 768px) {
        .wer-exchange-container {
            margin: 15px 0;
            border-radius: 12px;
        }
        
        .wer-table-header {
            padding: 20px;
        }
        
        .wer-header-title h2 {
            font-size: 20px;
        }
        
        .wer-exchange-table th,
        .wer-exchange-table td {
            padding: 12px 8px;
            font-size: 13px;
        }
        
        .currency-header {
            gap: 2px;
        }
        
        .currency-flag {
            font-size: 16px;
        }
        
        .currency-name {
            font-size: 10px;
        }
        
        .price-value, .avg-value {
            font-size: 14px;
        }
        
        .wer-table-footer {
            flex-direction: column;
            text-align: center;
            gap: 15px;
            padding: 15px;
        }
        
        .volume-mobile-wrapper {
            margin-top: 8px;
        }
        
        .volume-toggle {
            background: #e2e8f0;
            border: none;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 11px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .social-icons {
            gap: 6px;
        }
        
        .social-icon {
            width: 32px;
            height: 32px;
            font-size: 14px;
        }
    }
    
    @media (max-width: 480px) {
        .wer-switch-btn {
            padding: 6px 15px;
            font-size: 12px;
        }
        
        .source-name {
            flex-direction: column;
            gap: 5px;
            align-items: flex-start;
        }
        
        .wer-source-info {
            min-width: 150px;
        }
        
        .social-icons {
            justify-content: flex-start;
        }
        
        .btn-profile {
            padding: 6px 12px;
            font-size: 12px;
        }
    }
    
    @media (max-width: 360px) {
        .wer-exchange-table {
            min-width: 700px;
        }
        
        .social-icon {
            width: 28px;
            height: 28px;
            font-size: 12px;
        }
    }
    </style>

    <?php
    return ob_get_clean();
}