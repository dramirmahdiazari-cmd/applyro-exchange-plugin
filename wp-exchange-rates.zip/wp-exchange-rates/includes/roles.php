<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('init', function () {

    if (!get_role('exchange_user')) {
        add_role(
            'exchange_user',
            'صراف',
            [
                'read' => true,
                'upload_files' => true
            ]
        );
    }

});
