<?php
if (!defined('ABSPATH')) {
    exit;
}



/*
|--------------------------------------------------------------------------
| Site 1 – MB BRU – RUB (قیمت فروش)
|--------------------------------------------------------------------------
*/
function wer_scrape_mbbru_rub() {

    global $wpdb;

    $url = 'https://www.mbbru.ru/fizicheskim-litsam/mb-rial/';

    $response = wp_remote_get($url, [
        'timeout' => 8,
        'headers' => [
            'User-Agent' => 'Mozilla/5.0 (compatible; ExchangeRatesBot/1.0)'
        ]
    ]);

    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
        return;
    }

    $body = wp_remote_retrieve_body($response);
    if (!$body) {
        return;
    }

    // پیدا کردن ردیف RUB/IRR
    if (preg_match_all('/<div class="phys-detail-table-row">(.*?)<\/div>/s', $body, $rows)) {

        foreach ($rows[1] as $row) {

            if (strpos($row, 'RUB/IRR') !== false) {

                if (preg_match_all('/<span.*?>(.*?)<\/span>/s', $row, $spans)) {

                    // span سوم = قیمت فروش (مثلاً 17 100)
                    if (isset($spans[1][2])) {

                        $price_raw = trim($spans[1][2]);
                        $price = (int) str_replace([' ', ','], '', $price_raw);

                        if ($price > 1000 && $price < 1000000) {

                            $source = 'MB BRU';
                            $currency = 'RUB';

                            // حذف ردیف‌های قدیمی همان روز قبل از ذخیره
                            $wpdb->delete(
                                $wpdb->prefix . 'exchange_prices',
                                [
                                    'source' => $source,
                                    'currency' => $currency,
                                    'run_date' => date('Y-m-d')
                                ]
                            );

                            wer_save_price($source, $currency, $price);
                        }
                    }
                }
                break; // وقتی پیدا شد، دیگه ادامه نده
            }
        }
    }
}


/*
|--------------------------------------------------------------------------
| Site 2 
|--------------------------------------------------------------------------
*/

function wer_scrape_BRSAPI_api() {
    global $wpdb;

    $api_url = "https://brsapi.ir/Api/Market/Gold_Currency.php?key=BTVsYJp5czWuppN6NUfYGvQRwnjM7cPB";

    $response = wp_remote_get($api_url, [
        'timeout' => 10,
        'headers' => [
            'User-Agent' => 'WordPress Exchange Bot'
        ]
    ]);

    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
        error_log('[WER] BRSAPI API request failed');
        return;
    }

    $body = wp_remote_retrieve_body($response);

    if (!$body) {
        error_log('[WER] BRSAPI API returned empty body');
        return;
    }

    $data = json_decode($body, true);

    if (!$data || !isset($data['currency'])) {
        error_log('[WER] BRSAPI API returned invalid JSON structure');
        return;
    }

    $source = 'BRSAPI';
    $target_currencies = ['USD', 'EUR', 'RUB', 'TRY'];

    foreach ($data['currency'] as $row) {
        $symbol = $row['symbol'] ?? '';
        if (in_array($symbol, $target_currencies)) {

            $price_raw = $row['price'] ?? 0;
            $price = floatval(str_replace([',', ' '], '', $price_raw))* 10;

            if ($price > 0) {

                // حذف ردیف‌های قدیمی همان روز قبل از ذخیره
                $wpdb->delete(
                    $wpdb->prefix . 'exchange_prices',
                    [
                        'source' => $source,
                        'currency' => $symbol,
                        'run_date' => date('Y-m-d')
                    ]
                );

                wer_save_price($source, $symbol, $price);
                error_log("[WER] Saved $symbol price: $price");
            }
        }
    }
}
