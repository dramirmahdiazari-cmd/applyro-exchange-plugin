function wer_exchange_dashboard_shortcode() {
    ?>
    <div id="wer-exchange-dashboard">
        <div style="margin-bottom:15px;">
            <button class="wer-btn" data-currency="USD">دلار</button>
            <button class="wer-btn" data-currency="EUR">یورو</button>
            <button class="wer-btn" data-currency="RUB">روبل</button>
            <button class="wer-btn" data-currency="TRY">لیر</button>
        </div>
        <canvas id="wer-exchange-chart" height="400"></canvas>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
    let ctx = document.getElementById('wer-exchange-chart').getContext('2d');
    let exchangeChart = new Chart(ctx, { type: 'line', data: { labels: [], datasets: [] } });

    function loadCurrencyChart(currency) {
        fetch('<?php echo admin_url("admin-ajax.php"); ?>', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'action=wer_get_currency_chart&currency=' + currency
        })
        .then(res => res.json())
        .then(data => {
            exchangeChart.data.labels = data.dates;
            exchangeChart.data.datasets = [{
                label: data.currency + ' میانگین قیمت روزانه (ریال)',
                data: data.prices,
                borderColor: 'rgba(54, 162, 235, 1)',
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                tension: 0.3,
                pointRadius: 3,
                pointHoverRadius: 6
            }];
            exchangeChart.update();
        });
    }

    // دکمه‌ها را وصل می‌کنیم
    document.querySelectorAll('#wer-exchange-dashboard .wer-btn').forEach(btn => {
        btn.addEventListener('click', e => {
            let currency = e.target.dataset.currency;
            loadCurrencyChart(currency);
        });
    });

    // بارگذاری پیش‌فرض (USD)
    loadCurrencyChart('USD');
    </script>
    <?php
add_shortcode('wer_exchange_dashboard', 'wer_exchange_dashboard_shortcode');
