<?php
if (!defined('ABSPATH')) {
    exit;
}

function wer_save_price($source, $currency, $price) {
    global $wpdb;

    $table = $wpdb->prefix . 'exchange_prices';

    $run_time = current_time('H:i:s'); // زمان دقیق
    $run_date = current_time('Y-m-d'); // تاریخ امروز

    $result = $wpdb->insert(
        $table,
        [
            'source' => $source,
            'currency' => $currency,
            'price' => $price,
            'run_time' => $run_time,
            'run_date' => $run_date,
        ],
        ['%s', '%s', '%f', '%s', '%s'] // نوع داده‌ها صحیح
    );

    if ($result === false) {
        error_log("[WER] Failed to insert $currency price from $source");
    } else {
        error_log("[WER] Successfully inserted $currency price from $source");
    }
}
