<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * اجرای کرون قیمت ارز (فعلاً فقط تست)
 */
function wer_run_exchange_cron() {

    // جلوگیری از اجرای همزمان
    if (get_transient('wer_cron_running')) {
        return;
    }

    set_transient('wer_cron_running', 1, 5 * MINUTE_IN_SECONDS);

    // ثبت لاگ تست (فعلاً فقط برای اطمینان)
    error_log('[WER] Cron executed at ' . current_time('mysql'));

    // فراخوانی اسکرپر روبل MB BRU
    require_once WER_PLUGIN_PATH . 'includes/scraper.php';
    require_once WER_PLUGIN_PATH . 'includes/database.php';

    wer_scrape_mbbru_rub();
    wer_scrape_BRSAPI_api();
    
    delete_transient('wer_cron_running');
}

